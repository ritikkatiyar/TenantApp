---
name: Cyan Nexus
colors:
  surface: '#041329'
  surface-dim: '#041329'
  surface-bright: '#2c3951'
  surface-container-lowest: '#010e24'
  surface-container-low: '#0d1c32'
  surface-container: '#112036'
  surface-container-high: '#1c2a41'
  surface-container-highest: '#27354c'
  on-surface: '#d6e3ff'
  on-surface-variant: '#bbc8d0'
  inverse-surface: '#d6e3ff'
  inverse-on-surface: '#233148'
  outline: '#869399'
  outline-variant: '#3c494e'
  surface-tint: '#5ed4ff'
  primary: '#9de2ff'
  on-primary: '#003545'
  primary-container: '#00ccff'
  on-primary-container: '#005369'
  inverse-primary: '#006782'
  secondary: '#adc7ff'
  on-secondary: '#002e68'
  secondary-container: '#4a8eff'
  on-secondary-container: '#00285b'
  tertiary: '#c5dcdf'
  on-tertiary: '#1f3436'
  tertiary-container: '#aac0c3'
  on-tertiary-container: '#3a4f52'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#bbe9ff'
  primary-fixed-dim: '#5ed4ff'
  on-primary-fixed: '#001f29'
  on-primary-fixed-variant: '#004d63'
  secondary-fixed: '#d8e2ff'
  secondary-fixed-dim: '#adc7ff'
  on-secondary-fixed: '#001a41'
  on-secondary-fixed-variant: '#004493'
  tertiary-fixed: '#d0e7ea'
  tertiary-fixed-dim: '#b4cbce'
  on-tertiary-fixed: '#091f21'
  on-tertiary-fixed-variant: '#364a4d'
  background: '#041329'
  on-background: '#d6e3ff'
  surface-variant: '#27354c'
typography:
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 48px
  card-padding: 32px
---

## Brand & Style
The design system is built for high-performance SaaS and technology platforms, emphasizing clarity, technological precision, and a forward-leaning aesthetic. It adopts a **Corporate Modern** style infused with **vibrant digital accents**, creating an environment that feels both professional and energetic. 

The brand personality is authoritative yet innovative. By utilizing a deep, atmospheric foundation contrasted against electric focal points, the UI evokes a sense of "smart power"—efficient, data-driven, and highly functional. The aesthetic is characterized by clean lines, generous negative space, and a refined use of depth that guides the user's focus toward critical actions.

## Colors
The palette is anchored by a high-contrast relationship between deep, recessive tones and luminous highlights. 

- **Primary Cyan (#00CCFF):** Used for primary buttons, active navigation states, and critical progress indicators. It serves as the "source of light" in the interface.
- **Deep Navy (#0A192F):** The structural foundation. This provides the professional weight required for high-density data environments.
- **Surface Variations:** Following the reference, cards use a very light, desaturated cyan-tinted white (#EDF7FA) to stand out against the soft atmospheric background (#D9F3F8). This inverted dark-on-light card approach for content areas ensures maximum readability while maintaining the "cool" tech-oriented temperature of the brand.
- **Status Tones:** A secondary blue (#007BFF) is used for secondary actions or gradients, while a soft red is reserved exclusively for destructive actions like the delete icons shown in the reference.

## Typography
The typography strategy balances modern approachability with technical precision. 

**Plus Jakarta Sans** is used for headlines to provide a friendly yet confident personality. Its geometric nature complements the digital-first aesthetic. **Inter** is the workhorse for body copy, chosen for its exceptional legibility in data-heavy layouts. For technical labels, button text, or micro-copy (like the "MANAGE" label), **JetBrains Mono** is introduced to reinforce the system's precise, developer-friendly feel.

Hierarchy is established through significant weight shifts. Headlines should always be bold, while body text remains regular weight to ensure a clean, uncluttered reading experience.

## Layout & Spacing
This design system utilizes a **fixed-width grid** for desktop to maintain optimal line lengths and component proportions, transitioning to a fluid model for mobile.

- **Desktop:** 12-column grid with a 1200px max-width container. 24px gutters provide ample breathing room between complex data cards.
- **Mobile:** 4-column fluid grid with 16px margins.
- **Rhythm:** An 8px linear scale governs all padding and margins. Vertical rhythm between sections (e.g., between the "My Properties" title and the first card) should be 40px (5x base) to emphasize section distinctness.

Internal card padding is generous (32px) to prevent content from feeling cramped, especially when using the vibrant cyan buttons which require space to breathe.

## Elevation & Depth
Elevation in this system is achieved through **Tonal Layering** rather than traditional heavy shadows.

- **Level 0 (Background):** The soft cyan wash (#D9F3F8).
- **Level 1 (Cards):** Light surfaces (#EDF7FA) with a very subtle, high-blur ambient shadow (Opacity 5%, Color #0A192F) to lift the content from the background.
- **Level 2 (Interactive):** Active elements like the "MANAGE" button use a vibrant gradient from #00CCFF to #007BFF. These do not use shadows but instead rely on "Inner Glow" or high-contrast color shifts to indicate depth.
- **Glassmorphism:** Navigation bars and bottom menus (like the Properties/AI switcher) should utilize a backdrop blur (20px) with a semi-transparent white fill (80% opacity) to maintain context of the content behind them.

## Shapes
The shape language is consistently **Rounded**, striking a balance between modern friendliness and professional structure.

- **Large Containers (Cards):** Use `rounded-xl` (24px) to create a soft, framing effect for the content.
- **Primary Buttons:** Use a full pill-shape (999px) for the main "MANAGE" or "ACTION" buttons to make them feel distinct from the rectangular containers they sit within.
- **Small Elements (Chips, Inputs):** Use `rounded-md` (8px) to maintain a crisp look at smaller scales.

## Components
- **Buttons:** Primary buttons are pill-shaped with a horizontal gradient (#00CCFF to #007BFF). Text is uppercase JetBrains Mono with an arrow icon for directional cues.
- **Cards:** White or very light cyan surfaces with 24px corner radii. They should include a "Delete" or "Utility" icon in the top right, placed within a subtle desaturated red container (#FDEDEE).
- **Navigation (Bottom Bar):** A floating, pill-shaped dock with a backdrop blur. Active states are indicated by a soft cyan circular background behind the icon.
- **Status Chips:** Small, semi-transparent overlays on images or map markers, using the primary cyan for "Active" and neutral grays for "Inactive."
- **Empty States:** Use simplified 3D isometric icons (as seen in the "Libsys" card) in the primary cyan color to maintain visual interest in low-data scenarios.